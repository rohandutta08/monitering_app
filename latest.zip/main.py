import threading, time, json
from screenshot import screenshot_loop
from history import save_browser_history
from updater import check_for_update

with open("config.json") as f:
    config = json.load(f)

threading.Thread(target=screenshot_loop, args=(config,), daemon=True).start()
threading.Thread(target=save_browser_history, args=(config,), daemon=True).start()
threading.Thread(target=check_for_update, args=(config,), daemon=True).start()

while True:
    time.sleep(60)
